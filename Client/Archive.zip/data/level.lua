--level boundaries
lvlXP = {}

lvlXP[1] = 0
lvlXP[2] = 5
lvlXP[3] = 20
lvlXP[4] = 50
lvlXP[5] = 100
lvlXP[6] = 200
lvlXP[7] = 400
lvlXP[8] = 1000
lvlXP[9] = 1500
lvlXP[10] = 3000
