function bindKeys()
  KEY_UP = "w"
  KEY_DOWN = "s"
  KEY_LEFT = "a"
  KEY_RIGHT = "d"
  KEY_RUN = "lshift"

  KEY_ATK_UP = "up"
  KEY_ATK_DOWN = "down"
  KEY_ATK_LEFT = "left"
  KEY_ATK_RIGHT = "right"
end

setting = {}
setting.audio = true
